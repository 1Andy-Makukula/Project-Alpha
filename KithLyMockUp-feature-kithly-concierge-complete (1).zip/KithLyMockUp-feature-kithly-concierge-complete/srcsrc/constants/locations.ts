export const locations = [
    { id: 'Lusaka', label: 'Lusaka' },
    { id: 'Ndola', label: 'Ndola' },
    { id: 'Livingstone', label: 'Livingstone' },
    { id: 'Kitwe', label: 'Kitwe' },
    { id: 'All', label: 'Global' },
];
